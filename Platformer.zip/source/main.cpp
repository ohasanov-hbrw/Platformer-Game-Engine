#include "raylib.h"
#include <stdlib.h>
#include <stdio.h>
#include "include/maps.h"
#include <GL/picaGL.h>

const int grav = 7;
const int screenWidth = 400;
const int screenHeight = 240;

int renderposx;
int xd;

typedef struct PlayerStruct
{
    float accel,yvel,power;
    bool jump;
    int flipped;
    int maxSpeed,jumppower;
    Rectangle collisionbox;
    Vector2 Position;
    int whereineedtogoishell;
    int touchingground;
    int renderposx;
    int renderposy;
	bool kafacolliding;
	Rectangle collisionrectangle;
	bool jetpack;
	Vector2 placeholderpos;
	float acceldegisken;
	float yveldegisken;
	int levelnum;
    
} playerStruct; 

typedef struct BoxStruct
{
	int xpos;
	int ypos;
	int yvel;
	int accel;
	float acceldegisken;
	float yveldegisken;
    
} boxStruct; 
void MoveBox(boxStruct*Box){
	if (Box->ypos > screenHeight+150){
		Box->ypos = screenHeight+150;
	}
	//yer cekimi
	Box->yvel += 0.3f;
	if (Box->yvel > 7) Box->yvel = 7;
	Vector2 yuvarlatirmis = {Box->xpos / 16, Box->ypos / 16};
	int x = yuvarlatirmis.x - 2;
	int y = yuvarlatirmis.y - 2;
	
	//collision detectiondan once ne yapiyodu
	if (Box->accel < 0) {
		Box->acceldegisken = 0.5f;
	}
	else {
		Box->acceldegisken = -0.5f;
	}
	if (Box->yvel < 0) {
		Box->yveldegisken = 0.3f;
	}
	else {
		Box->yveldegisken = -0.3f;
	}
	//etrafinda 3 blok kontrol et
	while (x<yuvarlatirmis.x+3){
		while (y<yuvarlatirmis.y+3){
			//oyuncunun kolijin boksunu aliyo
			Rectangle boxbox = {Box->xpos + Box->accel ,Box->ypos + Box->yvel,16,16};
			Rectangle dirtbox = {x*16,y*16,16,16};
			
			
			//collision algilama
			if (CheckCollisionRecs(boxbox, dirtbox)){
				if(ship[ y ][ x ] == 11 || ship[ y ][ x ] == 16 || ship[ y ][ x ] == 10 || ship[ y ][ x ] == 5){
					//x kolijini
					while (true) {
						//hangi sekilde dokunuyo
						
						Rectangle boxbox = {Box->xpos + Box->accel,Box->ypos,16,16};
						if (!CheckCollisionRecs(boxbox, dirtbox)){
							break;
						}
						Box->accel = Box->accel + Box->acceldegisken;
					}
					//y kolijini
					while (true) {
						//hangi sekilde dokunuyo
						
						Rectangle boxbox = {Box->xpos,Box->ypos + Box->yvel,16,16};
						if (!CheckCollisionRecs(boxbox, dirtbox)){
							break;
						}
						Box->yvel = Box->yvel + Box->yveldegisken;
						
					}
				}	
				else {
					
				}
			}	
			//sonraki tura gec
			y += 1;
		}
		//sonraki tura gec
		y = 0;
		x += 1;
	}
	//eninde sonunda haraket edecek yavrucagiz
	Box->xpos += Box->accel;
	Box->ypos += Box->yvel;
}

void MovePlayer(playerStruct*Player)
{

    //Hareket etmedikce yavaslat
	if (!IsGamepadButtonDown(0, GAMEPAD_BUTTON_LEFT_FACE_LEFT) && !IsGamepadButtonDown(0, GAMEPAD_BUTTON_LEFT_FACE_RIGHT)) {
            Player->accel /= 1.2f;
	}   
	//yere dogru maks hiz
	if (Player->yvel > grav){
        Player->yvel = grav;
    }
	//saga doru git
    if(IsGamepadButtonDown(0, GAMEPAD_BUTTON_LEFT_FACE_RIGHT)){
        Player->accel += 0.5f;
    }
    //sola doru git
    if(IsGamepadButtonDown(0, GAMEPAD_BUTTON_LEFT_FACE_LEFT)){ 
        Player->accel -= 0.5f;
    }
    //saga gidiyosa saga don
    if (Player->accel > 0){
        Player->flipped = 0;
	}
	//sola gidiyosa sola don
    if (Player->accel < 0) {
       Player->flipped = 1;
	}
        
	//maks hizi
	if (Player->accel > Player->maxSpeed) 
		Player->accel = Player->maxSpeed;
	//maks hizi
	if (Player->accel < -Player->maxSpeed) 
		Player->accel = -Player->maxSpeed;
	//yere dusmemesi icin koruma XD
	if (Player->Position.y > screenHeight+150){
		Player->Position.y = screenHeight+150;
		Player->jump = true;
	}
       
	//yer cekimi
	Player->yvel += 0.3f;
	
	
	//ziplama
	if(IsGamepadButtonDown(0, GAMEPAD_BUTTON_RIGHT_FACE_RIGHT) && Player->jump && !IsGamepadButtonDown(0, GAMEPAD_BUTTON_RIGHT_FACE_DOWN)){
		Player->yvel = -Player->jumppower;
		Player->jump = false;
	}
	//jetpack
	if(IsGamepadButtonDown(0, GAMEPAD_BUTTON_RIGHT_FACE_DOWN) && Player->yvel > -grav){
		Player->yvel = Player->yvel-Player->power;
	}
	
	//pozisyonu tilelara ayirmak
	Vector2 yuvarlatirmis = {Player->Position.x / 16, Player->Position.y / 16};
	int x = yuvarlatirmis.x - 2;
	int y = yuvarlatirmis.y - 2;
	
	//collision detectiondan once ne yapiyodu
	if (Player->accel < 0) {
		Player->acceldegisken = 0.5f;
	}
	else {
		Player->acceldegisken = -0.5f;
	}
	if (Player->yvel < 0) {
		Player->yveldegisken = 0.3f;
	}
	else {
		Player->yveldegisken = -0.3f;
	}
	//etrafinda 3 blok kontrol et
	while (x<yuvarlatirmis.x+3){
		while (y<yuvarlatirmis.y+3){
			//oyuncunun kolijin boksunu aliyo
			Rectangle playerbox = {Player->Position.x + Player->accel - 6 ,Player->Position.y + Player->yvel - 28,12,28};
			Rectangle dirtbox = {x*16,y*16,16,16};
			
			
			//collision algilama
			if (CheckCollisionRecs(playerbox, dirtbox)){
				if(ship[ y ][ x ] == 11 || ship[ y ][ x ] == 16 || ship[ y ][ x ] == 10 || ship[ y ][ x ] == 5){
					//x kolijini
					while (true) {
						//hangi sekilde dokunuyo
						Player->touchingground = 1;
						Rectangle playerbox = {Player->Position.x + Player->accel - 6 ,Player->Position.y - 28,12,28};
						if (!CheckCollisionRecs(playerbox, dirtbox)){
							break;
						}
						Player->accel = Player->accel + Player->acceldegisken;
					}
					//y kolijini
					while (true) {
						//hangi sekilde dokunuyo
						Player->touchingground = 2;
						Rectangle playerbox = {Player->Position.x - 6 ,Player->Position.y + Player->yvel - 28,12,28};
						if (!CheckCollisionRecs(playerbox, dirtbox)){
							break;
						}
						Player->yvel = Player->yvel + Player->yveldegisken;
						Player->jump = true;
					}
				}	
				else {
					Player->touchingground = 0;
				}
			}	
			//sonraki tura gec
			y += 1;
		}
		//sonraki tura gec
		y = 0;
		x += 1;
	}
	//eninde sonunda haraket edecek yavrucagiz
	Player->Position.x += Player->accel;
	Player->Position.y += Player->yvel;
}

int main(void)
{
    //chdir("sdmc:/");
    playerStruct Player;
	boxStruct Box;
    Player.Position.x = (float)screenWidth/2;
    Player.Position.y = (float)screenHeight/2;
	Box.xpos = 240;
	Box.ypos = 10;
    Player.power = 0.7f;
    Player.maxSpeed = 6;
    Player.jumppower = 6;
	Vector2 playerpos;
    Player.levelnum = 0;
    //map--------------------------------------------------------------------------
    Player.jetpack = true;
    int loadedlevel = 0;
    Player.flipped = 0;
    
    //map--------------------------------------------------------------------------
    Rectangle sourceRec = { 0.0f, 0.0f, 32, 32 };
    Vector2 origin = { 16, 32 };
    
    InitWindow(screenWidth, screenHeight, "Platformer Test by OHASANOV");

    Image govde = LoadImage("3ds/platformer_data/gfx/Govde1.png"); 
    ImageFormat(&govde, UNCOMPRESSED_R8G8B8A8);
    Texture2D Govde[2];
    Govde[0] = LoadTextureFromImage(govde);
    ImageFlipHorizontal(&govde);
    Govde[1] = LoadTextureFromImage(govde);

    Image shipImage = LoadImage("3ds/platformer_data/gfx/shipTileSet.png");
    Texture2D shipTex = LoadTextureFromImage(shipImage); 
    int shipXTileCount = 5;
	
	Image boxImg = LoadImage("3ds/platformer_data/gfx/box.png");
	Texture2D box = LoadTextureFromImage(boxImg); 
	
    Image kafa = LoadImage("3ds/platformer_data/gfx/Kafa.png");
    ImageFormat(&kafa, UNCOMPRESSED_R8G8B8A8);
    Texture2D Kafa[2];
    Kafa[0] = LoadTextureFromImage(kafa);
    ImageFlipHorizontal(&kafa);
    Kafa[1] = LoadTextureFromImage(kafa);

    Camera2D camera = { 0 };
    
    camera.offset = (Vector2){ screenWidth/2, screenHeight/2 };
    camera.rotation = 0.0f;
    camera.zoom = 1.0f;
    
    SetTargetFPS(60); 

    while (!WindowShouldClose()) 
    {

        MovePlayer(&Player);
		MoveBox(&Box);
        camera.target = (Vector2){ Player.Position.x, Player.Position.y-50};
        
        Rectangle destRec = { Player.Position.x, Player.Position.y, 32, 32 };
		
		if (Player.levelnum == 0 && loadedlevel != 0){
			
		}
        else if (Player.levelnum == 0){
			
		}
		SetWindowMonitor(0);
        BeginDrawing();
            ClearBackground(BLACK);
            BeginMode2D(camera);
                //cizme
                playerpos.x = (int) destRec.x/16 - 15;
				if (playerpos.x < 0) playerpos.x=0;
				
				playerpos.y = (int) destRec.y/16 - 15;
				if (playerpos.y < 0) playerpos.y=0;
                int yd = playerpos.y;
				int maksx = ((int) destRec.x/16 + 15);
				int maksy = ((int) destRec.y/16 + 15);
				if (maksx > 50) maksx = 50;
				if (maksy > 15) maksy = 15;
                while (yd < maksy){
					int xd = playerpos.x;
					while (xd < maksx){
                        int tile = ship[ yd ][ xd ];
						//if (tile != 6){
							DrawTextureRec(shipTex,(Rectangle){(tile%shipXTileCount)*16,(int)(tile/shipXTileCount)*16,16,16},(Vector2){xd*16,yd*16},WHITE);
						//}
						xd = xd + 1;
					}
                yd = yd +1;
                }
				DrawTexturePro(Govde[Player.flipped], sourceRec, destRec, origin, (int)Player.accel, WHITE);
                DrawTexturePro(Kafa[Player.flipped], sourceRec, destRec, origin, (int)Player.accel, WHITE);
				DrawTexture(box, Box.xpos, Box.ypos , WHITE);
                
            EndMode2D(); 
			//SetWindowMonitor(1);
            DrawText(FormatText("X [%i]:", (int)Player.Position.x ), 90, 10, 20, RED);
            DrawText(FormatText("Y [%i]:", (int)Player.Position.y ), 170, 10, 20, RED);
			
			pglSwapBuffers();
			SetWindowMonitor(1);
			ClearBackground(BLACK);
			DrawText(FormatText("YEY 2. EKRAN"), 90, 10, 20, RED);
            DrawFPS(290, 10);
        EndDrawing(); 

    }
    CloseWindow();
    UnloadTexture(Govde[0]);
    UnloadTexture(Govde[1]);
    UnloadTexture(Kafa[0]);
    UnloadTexture(Kafa[1]);
    UnloadImage(kafa);
    UnloadImage(govde);
    return 0;
}
