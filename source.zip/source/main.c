#include "raylib.h"
#include <stdlib.h>
//#include <3ds.h>
#include <stdio.h>



const int grav = 7;
const int screenWidth = 400;
const int screenHeight = 240;

int renderposx;
int lvl1[20][20] = {
    
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1},
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1},
    {1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1}
};
    int xd;
typedef struct PlayerStruct
{
    float accel,yvel,power;
    bool jump;
    int flipped;
    int maxSpeed,jumppower;
    Rectangle collisionbox;
    Vector2 Position;
    int whereineedtogoishell;
    int touchingground;
    int renderposx;
    int renderposy;
	bool kafacolliding;
	Rectangle collisionrectangle;
	bool jetpack;
	Vector2 placeholderpos;
	Rectangle playerbox;
	Rectangle dirtbox;

    
} playerStruct; 
void MovePlayer(playerStruct*Player)
{

    if (!IsKeyDown(KEY_LEFT) && !IsKeyDown(KEY_RIGHT)) {
            Player->accel /= 1.2f;
	}
        
        
	if (Player->yvel > grav){
        Player->yvel = grav;
    }
    if(){
        Player->accel += 0.5f;
    }
        
    if(IsKeyDown(KEY_LEFT_SHIFT)){ 
        Player->accel -= 0.5f;
    }
        
    if (Player->accel > 0){
        Player->flipped = 0;
	}
    if (Player->accel < 0) {
       Player->flipped = 1;
	}
        
        
        if (Player->accel > Player->maxSpeed) 
            Player->accel = Player->maxSpeed;
        if (Player->accel < -Player->maxSpeed) 
            Player->accel = -Player->maxSpeed;
        
        
		
        
        
        if (Player->Position.y > screenHeight+150){
            Player->Position.y = screenHeight+150;
            
            Player->jump = true;
        }
       
		
		Player->yvel += 0.3f;
		
		
		
		if(IsKeyDown(KEY_SPACE) && Player->jump && !IsKeyDown(KEY_LEFT_SHIFT){
			Player->yvel = -Player->jumppower;
			Player->jump = false;
		}
        
		if(IsKeyDown(KEY_LEFT_SHIFT) && Player->yvel > -grav){
			Player->yvel = Player->yvel-Player->power;
		}\
		
		Vector2 yuvarlatirmis = {Player->Position.x / 16, Player->Position.y / 16};
		int x = yuvarlatirmis.x;
		int y = yuvarlatirmis.y;
		x-= 3;
		y-= 3;
		
		while (x < yuvarlatirmis.x + 3){
			while (y < yuvarlatirmis.y + 3){
				Rectangle playerbox = {(Player->Position.x - 6) + Player->accel,(Player->Position.y - 28) + Player->yvel,12,28};
				Rectangle dirtbox = {x*16,y*16,16,16};
				if (CheckCollisionRecs(playerbox, dirtbox)) {
					Player->touchingground = 1;
					
					Player->playerbox.x = (Player->Position.x - 6) + Player->accel;
					Player->playerbox.y = (Player->Position.y - 28) + Player->yvel;
					Player->playerbox.width = 12;
					Player->playerbox.height = 28;
					Player->dirtbox.x = x*16;
					Player->dirtbox.y = y*16;
					Player->dirtbox.width = 16;
					Player->dirtbox.height = 16;
					
					
					if(lvl1[y][x] == 1){
						 
						
						Player->collisionrectangle = GetCollisionRec(Player->playerbox, Player->dirtbox);
					
					
						Player->playerbox.x = (Player->Position.x - 6) + Player->accel;
						Player->playerbox.y = (Player->Position.y - 28);
						Player->playerbox.width = 12;
						Player->playerbox.height = 28;
						
						while (CheckCollisionRecs(Player->playerbox, Player->dirtbox)){
							if (Player->accel < 0) Player->accel = Player->accel + 1;
							if (Player->accel > 0) Player->accel = Player->accel - 1 ;
							Player->playerbox.x = (Player->Position.x - 6) + Player->accel;
						}
						
						Player->playerbox.x = (Player->Position.x - 6);
						Player->playerbox.y = (Player->Position.y - 28) + Player->yvel;
						Player->playerbox.width = 12;
						Player->playerbox.height = 28;
					
						while (CheckCollisionRecs(Player->playerbox, Player->dirtbox)){
							if (Player->yvel < 0) Player->yvel = Player->yvel + 1;
							if (Player->yvel > 0) Player->yvel = Player->yvel - 1 ;
							Player->playerbox.y = (Player->Position.y - 28) + Player->yvel;
						}
					}
					
				}
				y += 1;
				
			}
		x += 1;
		}
		
		
		
		
		
		Player->Position.x += Player->accel;
		Player->Position.y += Player->yvel;
		
		
		
		
		
		
		
		
        
}

int main(void)
{
    //chdir("sdmc:/");
    playerStruct Player;
	
    Player.Position.x = (float)screenWidth/2;
    Player.Position.y = (float)screenHeight/2;
    Player.power = 0.7f;
    Player.maxSpeed = 6;
    Player.jumppower = 6;

    
    //map--------------------------------------------------------------------------
    Player.jetpack = true;
    
    Player.flipped = 0;
    
    //map--------------------------------------------------------------------------
    Rectangle sourceRec = { 0.0f, 0.0f, 32, 32 };
    Vector2 origin = { 16, 32 };
    
    InitWindow(screenWidth, screenHeight, "Platformer Test by OHASANOV");

    Image govde = LoadImage("3ds/platformer_data/gfx/Govde1.png"); 
    ImageFormat(&govde, UNCOMPRESSED_R8G8B8A8);
    Texture2D Govde[2];
    Govde[0] = LoadTextureFromImage(govde);
    ImageFlipHorizontal(&govde);
    Govde[1] = LoadTextureFromImage(govde);

    Image dirt = LoadImage("3ds/platformer_data/gfx/Dirt.png");
    Texture2D Dirt = LoadTextureFromImage(dirt); 

    Image kafa = LoadImage("3ds/platformer_data/gfx/Kafa.png");
    ImageFormat(&kafa, UNCOMPRESSED_R8G8B8A8);
    Texture2D Kafa[2];
    Kafa[0] = LoadTextureFromImage(kafa);
    ImageFlipHorizontal(&kafa);
    Kafa[1] = LoadTextureFromImage(kafa);

    Camera2D camera = { 0 };
    
    camera.offset = (Vector2){ screenWidth/2, screenHeight/2 };
    camera.rotation = 0.0f;
    camera.zoom = 1.0f;
    
    SetTargetFPS(60); 

    while (!WindowShouldClose()) 
    {

        MovePlayer(&Player);

        camera.target = (Vector2){ Player.Position.x, Player.Position.y-50};
        
        Rectangle destRec = { Player.Position.x, Player.Position.y, 32, 32 };
        
        BeginDrawing();
        
            ClearBackground(RAYWHITE);
            
            
            BeginMode2D(camera);
                DrawRectangleLines(0, 0, 400, 240, RED);
                DrawTexturePro(Govde[Player.flipped], sourceRec, destRec, origin, (int)Player.accel, WHITE);
                DrawTexturePro(Kafa[Player.flipped], sourceRec, destRec, origin, (int)Player.accel, WHITE);
                
                
                int yd = 0;
                while (yd < 20){
                int xd = 0;
                while (xd<20){
                    if (lvl1[yd][xd] == 1){
                        DrawTexture(Dirt, xd*16 ,yd*16 ,WHITE);
                    }
                    xd = xd + 1;
                }
                yd = yd +1;
                }
                
            EndMode2D(); 
            DrawText(FormatText("X [%i]:", (int)Player.Position.x ), 10, 10, 20, RED);
            DrawText(FormatText("Y [%i]:", (int)Player.Position.y ), 90, 10, 20, RED);
            
            DrawText(FormatText("E.T. [%i]:", Player.touchingground ), 170, 10, 20, RED);
            DrawFPS(290, 10);
            
        EndDrawing(); 
    }
    CloseWindow();
    UnloadTexture(Govde[0]);
    UnloadTexture(Govde[1]);
    UnloadTexture(Kafa[0]);
    UnloadTexture(Kafa[1]);
    UnloadImage(kafa);
    UnloadImage(govde);
    return 0;
}
